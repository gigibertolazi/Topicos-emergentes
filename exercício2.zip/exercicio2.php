<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="custom.css">
</head>
<body>
    <form method="POST" action="pagina_protegida.php">
        Informe seu nome de usuário e senha:
            <br><br>
            <input type="text" name="usuario" value="Usuário">
            <br>
            <input type="password" name="senha" value="Senha">
            <br><br>
            <input type="submit" value="Fazer login">

    </form>
</body>
</html>