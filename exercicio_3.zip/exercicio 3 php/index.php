<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculador de nota</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="notasFinais.php">
        Informe sua média final do semestre:
            <br><br>
            <input type="text" name="semestreNota" value="Insira aqui" size="20">
            <br><br>
            <input type="submit" value="Calcular">

    </form>
</body>
</html>