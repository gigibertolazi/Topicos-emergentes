<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário</title>
</head>
<body>
    <form method="POST" action="form1.php">
        Digite seu nome:
        <br>
        <input type="text" name="nome">
        <br><br>
        Digite sua idade:
        <br>
        <input type="text" name="idade">
        <br><br>
        Informe o seu endereço:
        <br>
        <input type="text" name="endereco">
        <br><br>
        Selecione o seu sexo:
        <br>
        <input type="radio" name="opcao" value="feminino">Feminino<br>
        <input type="radio" name="opcao" value="masculino">Masculino<br>
        <br>

        <input type="submit" value="Enviar">
        
    



    </form>
</body>
</html>